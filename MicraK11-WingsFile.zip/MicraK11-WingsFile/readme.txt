NISSAN MICRA K11 car model for Wings 3D
(c) Rene Bui
www.renebui-onlinestudio.com

This creation is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License. 
http://creativecommons.org/licenses/by-nc/3.0/
